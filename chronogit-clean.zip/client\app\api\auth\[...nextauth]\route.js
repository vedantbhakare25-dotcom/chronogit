import NextAuth from 'next-auth';
import GoogleProvider from 'next-auth/providers/google';
import CredentialsProvider from 'next-auth/providers/credentials';
import { expressFetch } from '@/lib/api';

export const authOptions = {
  providers: [
    GoogleProvider({
      clientId: process.env.GOOGLE_CLIENT_ID || 'dummy_id',
      clientSecret: process.env.GOOGLE_CLIENT_SECRET || 'dummy_secret',
    }),
    CredentialsProvider({
      id: 'demo-login',
      name: 'Demo Account',
      credentials: {},
      async authorize() {
        return {
          id: 'google_demo_101',
          name: 'Vedant Bhakare (Demo)',
          email: 'vedant.demo@example.com',
          image: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Vedant',
        };
      },
    }),
  ],
  session: {
    strategy: 'jwt',
  },
  callbacks: {
    async signIn({ user, account }) {
      try {
        const googleId = account?.providerAccountId || user.id;
        const syncedUser = await expressFetch('/api/users/sync', {
          method: 'POST',
          body: {
            googleId,
            email: user.email,
            name: user.name,
            avatar: user.image,
          },
        });
        user.mongoId = syncedUser?.id || '000000000000000000000001';
        return true;
      } catch (err) {
        console.error('[auth] failed to sync user with express:', err);
        user.mongoId = '000000000000000000000001';
        return true;
      }
    },
    async jwt({ token, user }) {
      if (user?.mongoId) {
        token.userId = user.mongoId;
      }
      return token;
    },
    async session({ session, token }) {
      if (token?.userId) {
        session.user.id = token.userId;
      }
      return session;
    },
  },
  secret: process.env.NEXTAUTH_SECRET || 'super-secret-chronogit-session-key-random-12345',
  pages: {
    signIn: '/',
  },
};

const handler = NextAuth(authOptions);
export { handler as GET, handler as POST };