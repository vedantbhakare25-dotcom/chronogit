import { AppError } from '../utils/AppError.js';

/**
 * Middleware for server-to-server calls from Next.js BFF.
 * In local/test runs without INTERNAL_API_SECRET configured, it falls back
 * gracefully to a test user ID so unit tests do not break.
 */
export function requireInternalAuth(req, res, next) {
  const secret = process.env.INTERNAL_API_SECRET;

  // In production / when secret is set, verify it
  if (secret) {
    const providedSecret = req.headers['x-internal-secret'];
    if (!providedSecret || providedSecret !== secret) {
      return next(new AppError('Invalid or missing internal service secret', 401));
    }
  }

  const userId = req.headers['x-user-id'];
  if (userId) {
    req.userId = userId;
  } else if (!secret) {
    // Test/dev fallback for single-user testing & legacy test suites
    req.userId = '000000000000000000000001';
  } else {
    return next(new AppError('Missing x-user-id header', 401));
  }

  next();
}